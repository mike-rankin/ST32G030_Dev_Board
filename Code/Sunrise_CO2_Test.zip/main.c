/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include <string.h>
#include "st7735.h"
#include "bme280.h"
#include "GFX_FUNCTIONS.h"
#include "fonts.h"

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;
SPI_HandleTypeDef hspi1;

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_I2C1_Init(void);
static void MX_SPI1_Init(void);
/* USER CODE BEGIN PFP */

float temperature;
float humidity;
float pressure;

struct bme280_dev dev;
struct bme280_data comp_data;
int8_t rslt;

char hum_string[50];
char temp_string[50];
char press_string[50];


#define SUNRISE_ADDR            0x68
#define ATTEMPTS                5
#define EEPROM_UPDATE_DELAY_MS  25
#define ERROR_STATUS            0x01
#define MEASUREMENT_MODE        0x95
#define METER_CONTROL           0xA5
#define CONTINUOUS              0x0000
#define SINGLE                  0x0001
int readPeriodMs = 4000;

uint16_t co2_value = 0;
uint8_t co2_error_status = 0;




/**
 * @brief  Wakes up the sensor by initializing a write operation
 *         with no data.
 *
 * @param  hi2c: Pointer to I2C handle
 * @param  target: The sensor's communication address
 * @retval true if successful, false if failed
 */
bool sunrise_wakeup(I2C_HandleTypeDef *hi2c, uint8_t target)
{
  int attempts = ATTEMPTS;
  HAL_StatusTypeDef status;

  do {
    status = HAL_I2C_Master_Transmit(hi2c, (target << 1), NULL, 0, 100);
    attempts--;
  } while((status != HAL_OK && status != HAL_ERROR) && (attempts > 0));

  return (attempts > 0);
}

/**
 * @brief  I2C read function for Sunrise sensor
 *
 * @param  hi2c: Pointer to I2C handle
 * @param  target: The sensor's communication address
 * @param  reg_addr: Register address to read from
 * @param  data: Pointer to data buffer
 * @param  len: Number of bytes to read
 * @retval HAL status
 */
HAL_StatusTypeDef sunrise_i2c_read(I2C_HandleTypeDef *hi2c, uint8_t target,
                                    uint8_t reg_addr, uint8_t *data, uint16_t len)
{
  HAL_StatusTypeDef status;

  // Write register address
  status = HAL_I2C_Master_Transmit(hi2c, (target << 1), &reg_addr, 1, 100);
  if(status != HAL_OK) return status;

  // Read data
  status = HAL_I2C_Master_Receive(hi2c, (target << 1) | 0x01, data, len, 100);

  return status;
}

/**
 * @brief  I2C write function for Sunrise sensor
 *
 * @param  hi2c: Pointer to I2C handle
 * @param  target: The sensor's communication address
 * @param  reg_addr: Register address to write to
 * @param  data: Pointer to data buffer
 * @param  len: Number of bytes to write
 * @retval HAL status
 */
HAL_StatusTypeDef sunrise_i2c_write(I2C_HandleTypeDef *hi2c, uint8_t target,
                                     uint8_t reg_addr, uint8_t *data, uint16_t len)
{
  uint8_t *buf;
  HAL_StatusTypeDef status;

  buf = malloc(len + 1);
  if(buf == NULL) return HAL_ERROR;

  buf[0] = reg_addr;
  memcpy(buf + 1, data, len);

  status = HAL_I2C_Master_Transmit(hi2c, (target << 1), buf, len + 1, 100);

  free(buf);
  return status;
}

/**
 * @brief  Reads the sensor's current measurement mode,
 *         measurement period and number of samples.
 *
 * @param  hi2c: Pointer to I2C handle
 * @param  target: The sensor's communication address
 * @retval None
 */
void sunrise_read_sensor_config(I2C_HandleTypeDef *hi2c, uint8_t target)
{
  HAL_StatusTypeDef status;
  uint8_t data[7];

  /* Wakeup */
  if(!sunrise_wakeup(hi2c, target)) {
    // Failed to wake up sensor
    return;
  }

  /* Read configuration registers */
  status = sunrise_i2c_read(hi2c, target, MEASUREMENT_MODE, data, 7);
  if(status != HAL_OK) {
    // Failed to read
    return;
  }

  /* Parse measurement mode */
  uint8_t measMode = data[0];

  /* Parse measurement period */
  uint16_t measPeriod = ((uint16_t)data[1] << 8) | (uint16_t)data[2];

  /* Parse number of samples */
  uint16_t numSamples = ((uint16_t)data[3] << 8) | (uint16_t)data[4];

  /* Parse ABC Period */
  uint16_t abcPeriod = ((uint16_t)data[5] << 8) | (uint16_t)data[6];

  /* Update reading period */
  readPeriodMs = measPeriod * 1000;

  /* Read meter control */
  if(!sunrise_wakeup(hi2c, target)) {
    return;
  }

  uint8_t meterControl;
  status = sunrise_i2c_read(hi2c, target, METER_CONTROL, &meterControl, 1);

  /* You can print these values or display on ST7735:
   * measMode, measPeriod, numSamples, abcPeriod, meterControl
   */
}

/**
 * @brief  Enable or disable ABC (Automatic Baseline Correction).
 *
 * @param  hi2c: Pointer to I2C handle
 * @param  target: The sensor's communication address
 * @param  enable: Set true to enable or false to disable ABC
 * @retval None
 */
void sunrise_set_abc(I2C_HandleTypeDef *hi2c, uint8_t target, bool enable)
{
  HAL_StatusTypeDef status;
  uint8_t meterControl;

  /* Wakeup */
  if(!sunrise_wakeup(hi2c, target)) {
    return;
  }

  /* Read current meter control value */
  status = sunrise_i2c_read(hi2c, target, METER_CONTROL, &meterControl, 1);
  if(status != HAL_OK) {
    return;
  }

  /* Modify ABC bit */
  if(enable) {
    meterControl &= (uint8_t)~0x02U;  // Clear bit 1 to enable ABC
  } else {
    meterControl |= 0x02U;             // Set bit 1 to disable ABC
  }

  /* Wakeup */
  if(!sunrise_wakeup(hi2c, target)) {
    return;
  }

  /* Write modified value back */
  status = sunrise_i2c_write(hi2c, target, METER_CONTROL, &meterControl, 1);
  HAL_Delay(EEPROM_UPDATE_DELAY_MS);
}

/**
 * @brief  Changes the sensor's current measurement mode to continuous
 *         if it's currently in single mode.
 *
 * @param  hi2c: Pointer to I2C handle
 * @param  target: The sensor's communication address
 * @retval None
 */
void sunrise_change_measurement_mode(I2C_HandleTypeDef *hi2c, uint8_t target)
{
  HAL_StatusTypeDef status;
  uint8_t measMode;
  uint8_t newMode[2] = {(CONTINUOUS >> 8) & 0xFF, CONTINUOUS & 0xFF};

  /* Wakeup */
  if(!sunrise_wakeup(hi2c, target)) {
    return;
  }

  /* Read current measurement mode */
  status = sunrise_i2c_read(hi2c, target, MEASUREMENT_MODE, &measMode, 1);
  if(status != HAL_OK) {
    return;
  }

  /* Change mode if not continuous */
  if(measMode != CONTINUOUS) {
    /* Wakeup */
    if(!sunrise_wakeup(hi2c, target)) {
      return;
    }

    /* Write continuous mode */
    uint8_t mode_byte = CONTINUOUS;
    status = sunrise_i2c_write(hi2c, target, MEASUREMENT_MODE, &mode_byte, 1);
    HAL_Delay(EEPROM_UPDATE_DELAY_MS);

    /* Note: Sensor restart may be required to apply changes */
  }
}

/**
 * @brief  Reads the sensor's current CO2 value and error status.
 *
 * @param  hi2c: Pointer to I2C handle
 * @param  target: The sensor's communication address
 * @retval None
 */
void sunrise_read_measurements(I2C_HandleTypeDef *hi2c, uint8_t target)
{
  HAL_StatusTypeDef status;
  uint8_t data[7];

  /* Wakeup */
  if(!sunrise_wakeup(hi2c, target)) {
    return;
  }

  /* Read measurement registers */
  status = sunrise_i2c_read(hi2c, target, ERROR_STATUS, data, 7);
  if(status != HAL_OK) {
    return;
  }

  /* Parse error status */
  co2_error_status = data[0];

  /* Skip reserved bytes (data[1-4]) */

  /* Parse CO2 value */
  co2_value = ((uint16_t)data[5] << 8) | (uint16_t)data[6];
}

/**
 * @brief  Initialize Sunrise CO2 sensor
 *
 * @param  hi2c: Pointer to I2C handle
 * @retval None
 */
void sunrise_init(I2C_HandleTypeDef *hi2c)
{
  /* Read sensor configuration */
  sunrise_read_sensor_config(hi2c, SUNRISE_ADDR);

  /* Optionally disable ABC if testing with CO2 < 400ppm */
  // sunrise_set_abc(hi2c, SUNRISE_ADDR, false);

  /* Change to continuous measurement mode if needed */
  sunrise_change_measurement_mode(hi2c, SUNRISE_ADDR);

  HAL_Delay(readPeriodMs);
}










int8_t user_i2c_read(uint8_t id, uint8_t reg_addr, uint8_t *data, uint16_t len)
{
  if(HAL_I2C_Master_Transmit(&hi2c1, (id << 1), &reg_addr, 1, 10) != HAL_OK) return -1;
  if(HAL_I2C_Master_Receive(&hi2c1, (id << 1) | 0x01, data, len, 10) != HAL_OK) return -1;
  return 0;
}

void user_delay_ms(uint32_t period)
{
  HAL_Delay(period);
}

int8_t user_i2c_write(uint8_t id, uint8_t reg_addr, uint8_t *data, uint16_t len)
{
  int8_t *buf;
  buf = malloc(len +1);
  buf[0] = reg_addr;
  memcpy(buf +1, data, len);

  if(HAL_I2C_Master_Transmit(&hi2c1, (id << 1), (uint8_t*)buf, len + 1, HAL_MAX_DELAY) != HAL_OK) return -1;

  free(buf);
  return 0;
}


int main(void)
{

  HAL_Init();
  SystemClock_Config();

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_I2C1_Init();
  MX_SPI1_Init();


  sunrise_init(&hi2c1);

  //BME280 init
  dev.dev_id = BME280_I2C_ADDR_SEC;
  dev.intf = BME280_I2C_INTF;
  dev.read = user_i2c_read;
  dev.write = user_i2c_write;
  dev.delay_ms = user_delay_ms;

  rslt = bme280_init(&dev);

  //BME280 settings
  dev.settings.osr_h = BME280_OVERSAMPLING_1X;
  dev.settings.osr_p = BME280_OVERSAMPLING_16X;
  dev.settings.osr_t = BME280_OVERSAMPLING_2X;
  dev.settings.filter = BME280_FILTER_COEFF_16;
  rslt = bme280_set_sensor_settings(BME280_OSR_PRESS_SEL | BME280_OSR_TEMP_SEL | BME280_OSR_HUM_SEL | BME280_FILTER_SEL, &dev);


  ST7735_Init();
   /* USER CODE END 2 */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, 1);
   /* Infinite loop */
  ST7735_FillScreen(ST7735_BLACK);
   /* USER CODE BEGIN WHILE */


  while (1)
  {
    //Forced mode setting, switched to SLEEP mode after measurement
    rslt = bme280_set_sensor_mode(BME280_FORCED_MODE, &dev);
    dev.delay_ms(40);
    //Get Data
    rslt = bme280_get_sensor_data(BME280_ALL, &comp_data, &dev);
    //ST7735_WriteString(0, 0, "Ready", Font_11x18, ST7735_GREEN, ST7735_BLACK);

    if(rslt == BME280_OK)
    {
 	//ST7735_WriteString(0, 0, "Sensor good", Font_11x18, ST7735_GREEN, ST7735_BLACK);
 	temperature = comp_data.temperature / 100.0;
 	humidity = comp_data.humidity / 1024.0;
 	pressure = comp_data.pressure / 10000.0;

     ST7735_WriteString(15, 0, "STM32G030C8T6 Dev", Font_7x10, ST7735_GREEN, ST7735_BLACK);
     ST7735_WriteString(5, 20, "Temp:", Font_11x18, ST7735_BLUE, ST7735_BLACK);
     ST7735_WriteString(5, 40, "Humid:", Font_11x18, ST7735_BLUE, ST7735_BLACK);
     ST7735_WriteString(5, 60, "CO2:", Font_11x18, ST7735_BLUE, ST7735_BLACK);

     ST7735_FillRectangle(130, 20, 5, 5, ST7735_CYAN);  //Temperature decimal
     ST7735_FillRectangle(131, 21, 3, 3, ST7735_BLACK);

     for(int x = 10; x < 150; x++)
     {
      ST7735_DrawPixel(x, 13, ST7735_WHITE);
      //ST7735_DrawPixel(x, ST7735_HEIGHT-1, ST7735_RED);
     }

     //Temp int to float
     char str1[100];
     int d1 = temperature;          //Get the integer part
     float f2 = temperature - d1;   // Get fractional part (678.0123 - 678 = 0.0123)
     //int d2 = trunc(f2 * 10);       // Turn into integer (123)
     int d2 = (f2 * 10);       // Turn into integer (123)
     sprintf (str1, "%d.%d", d1, d2);
     ST7735_WriteString(80, 20, str1, Font_11x18, ST7735_CYAN, ST7735_BLACK);


     //Hum int to float
     char str2[100];
     int d3 = humidity;          //Get the integer part
     float f3 = humidity - d3;   // Get fractional part (678.0123 - 678 = 0.0123)
     int d4 = (f3 * 10);       // Turn into integer (123)
     sprintf (str2, "%d.%d", d3, d4);
     ST7735_WriteString(80, 40, str2, Font_11x18, ST7735_CYAN, ST7735_BLACK);


     /*
     //Pressure int to float
     char str3[100];
     int d5 = pressure;          //Get the integer part
     float f4 = pressure - d5;   // Get fractional part (678.0123 - 678 = 0.0123)
     int d6 = (f4 * 10);       // Turn into integer (123)
     sprintf (str3, "%d.%d", d5, d6);
     ST7735_WriteString(80, 60, str3, Font_11x18, ST7735_CYAN, ST7735_BLACK);
     */



     // Read CO2 sensor
     sunrise_read_measurements(&hi2c1, SUNRISE_ADDR);

     // Display CO2 data on ST7735
     char co2_string[50];
     sprintf(co2_string, "%d ppm", co2_value);
     ST7735_WriteString(65, 60, co2_string, Font_11x18, ST7735_CYAN, ST7735_BLACK);




    }
   }
 }

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = RCC_PLLM_DIV5;
  RCC_OscInitStruct.PLL.PLLN = 64;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV5;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.Timing = 0x00602173;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Analogue filter
  */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c1, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Digital filter
  */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c1, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief SPI1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI1_Init(void)
{

  /* USER CODE BEGIN SPI1_Init 0 */

  /* USER CODE END SPI1_Init 0 */

  /* USER CODE BEGIN SPI1_Init 1 */

  /* USER CODE END SPI1_Init 1 */
  /* SPI1 parameter configuration*/
  hspi1.Instance = SPI1;
  hspi1.Init.Mode = SPI_MODE_MASTER;
  hspi1.Init.Direction = SPI_DIRECTION_1LINE;
  hspi1.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi1.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi1.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi1.Init.NSS = SPI_NSS_SOFT;
  hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_32;
  hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi1.Init.CRCPolynomial = 7;
  hspi1.Init.CRCLength = SPI_CRC_LENGTH_DATASIZE;
  hspi1.Init.NSSPMode = SPI_NSS_PULSE_ENABLE;
  if (HAL_SPI_Init(&hspi1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI1_Init 2 */

  /* USER CODE END SPI1_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOF_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_3|GPIO_PIN_4|GPIO_PIN_5, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, GPIO_PIN_RESET);

  /*Configure GPIO pin : PC13 */
  GPIO_InitStruct.Pin = GPIO_PIN_13;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : PA3 PA4 PA5 */
  GPIO_InitStruct.Pin = GPIO_PIN_3|GPIO_PIN_4|GPIO_PIN_5;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : PB0 */
  GPIO_InitStruct.Pin = GPIO_PIN_0;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : PB1 */
  GPIO_InitStruct.Pin = GPIO_PIN_1;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
