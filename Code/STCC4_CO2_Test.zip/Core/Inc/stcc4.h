/**
 * @file stcc4.h
 * @brief STCC4 CO2 Sensor Driver for STM32 HAL
 * @note Converted from Sensirion Arduino library to STM32 HAL
 */

#ifndef STCC4_H
#define STCC4_H

#include "stm32g0xx_hal.h"
#include <stdint.h>
#include <stdbool.h>

/* I2C Address */
#define STCC4_I2C_ADDR 0x64  //Normally 65

/* Command IDs */
#define STCC4_CMD_START_CONTINUOUS      0x218B
#define STCC4_CMD_READ_MEASUREMENT      0xEC05
#define STCC4_CMD_STOP_CONTINUOUS       0x3F86
#define STCC4_CMD_MEASURE_SINGLE_SHOT   0x219D
#define STCC4_CMD_FORCED_RECALIBRATION  0x362F
#define STCC4_CMD_GET_PRODUCT_ID        0x365B
#define STCC4_CMD_SET_RHT_COMPENSATION  0xE000
#define STCC4_CMD_SET_PRESSURE_RAW      0xE016
#define STCC4_CMD_SELF_TEST             0x278C
#define STCC4_CMD_CONDITIONING          0x29BC
#define STCC4_CMD_ENTER_SLEEP           0x3650
#define STCC4_CMD_EXIT_SLEEP            0x0000
#define STCC4_CMD_ENABLE_TEST_MODE      0x3FBC
#define STCC4_CMD_DISABLE_TEST_MODE     0x3F3D
#define STCC4_CMD_FACTORY_RESET         0x3632

/* Timeouts (ms) */
#define STCC4_I2C_TIMEOUT               1000
#define STCC4_DELAY_START_MEASURE       0
#define STCC4_DELAY_READ_MEASURE        1
#define STCC4_DELAY_STOP_MEASURE        1200
#define STCC4_DELAY_SINGLE_SHOT         500
#define STCC4_DELAY_FORCED_RECAL        90
#define STCC4_DELAY_GET_PRODUCT_ID      1
#define STCC4_DELAY_SET_RHT             1
#define STCC4_DELAY_SET_PRESSURE        1
#define STCC4_DELAY_SELF_TEST           360
#define STCC4_DELAY_CONDITIONING        22000
#define STCC4_DELAY_ENTER_SLEEP         2
#define STCC4_DELAY_EXIT_SLEEP          5

/* Error codes */
typedef enum {
    STCC4_OK = 0,
    STCC4_ERR_I2C = -1,
    STCC4_ERR_CRC = -2,
    STCC4_ERR_TIMEOUT = -3,
    STCC4_ERR_PARAM = -4
} STCC4_Status_t;

/* Measurement data structure */
typedef struct {
    int16_t co2_ppm;
    float temperature_c;
    float humidity_percent;
    uint16_t sensor_status;
} STCC4_Measurement_t;

/* Device handle structure */
typedef struct {
    I2C_HandleTypeDef *hi2c;
    uint8_t i2c_addr;
} STCC4_Handle_t;

/* Function prototypes */

/**
 * @brief Initialize STCC4 sensor
 * @param handle Pointer to device handle
 * @param hi2c Pointer to I2C handle
 * @param i2c_addr I2C address (usually STCC4_I2C_ADDR)
 * @return STCC4_OK on success
 */
STCC4_Status_t STCC4_Init(STCC4_Handle_t *handle, I2C_HandleTypeDef *hi2c, uint8_t i2c_addr);

/**
 * @brief Start continuous measurement (1 Hz)
 * @param handle Pointer to device handle
 * @return STCC4_OK on success
 */
STCC4_Status_t STCC4_StartContinuousMeasurement(STCC4_Handle_t *handle);

/**
 * @brief Stop continuous measurement
 * @param handle Pointer to device handle
 * @return STCC4_OK on success
 */
STCC4_Status_t STCC4_StopContinuousMeasurement(STCC4_Handle_t *handle);

/**
 * @brief Read measurement data
 * @param handle Pointer to device handle
 * @param measurement Pointer to measurement structure
 * @return STCC4_OK on success
 */
STCC4_Status_t STCC4_ReadMeasurement(STCC4_Handle_t *handle, STCC4_Measurement_t *measurement);

/**
 * @brief Perform single shot measurement
 * @param handle Pointer to device handle
 * @return STCC4_OK on success
 */
STCC4_Status_t STCC4_MeasureSingleShot(STCC4_Handle_t *handle);

/**
 * @brief Get product ID and serial number
 * @param handle Pointer to device handle
 * @param product_id Pointer to store 32-bit product ID
 * @param serial_number Pointer to store 64-bit serial number
 * @return STCC4_OK on success
 */
STCC4_Status_t STCC4_GetProductId(STCC4_Handle_t *handle, uint32_t *product_id, uint64_t *serial_number);

/**
 * @brief Set pressure compensation
 * @param handle Pointer to device handle
 * @param pressure_pa Pressure in Pascals
 * @return STCC4_OK on success
 */
STCC4_Status_t STCC4_SetPressureCompensation(STCC4_Handle_t *handle, uint16_t pressure_pa);

/**
 * @brief Set RH/T compensation from raw SHT4x values
 * @param handle Pointer to device handle
 * @param raw_temp Raw temperature value from SHT4x
 * @param raw_humidity Raw humidity value from SHT4x
 * @return STCC4_OK on success
 */
STCC4_Status_t STCC4_SetRhtCompensation(STCC4_Handle_t *handle, uint16_t raw_temp, uint16_t raw_humidity);

/**
 * @brief Perform forced recalibration
 * @param handle Pointer to device handle
 * @param target_co2_ppm Target CO2 concentration in ppm
 * @param frc_correction Pointer to store FRC correction value
 * @return STCC4_OK on success
 */
STCC4_Status_t STCC4_PerformForcedRecalibration(STCC4_Handle_t *handle, int16_t target_co2_ppm, int16_t *frc_correction);

/**
 * @brief Perform self-test
 * @param handle Pointer to device handle
 * @param test_result Pointer to store test result (0 = pass)
 * @return STCC4_OK on success
 */
STCC4_Status_t STCC4_PerformSelfTest(STCC4_Handle_t *handle, uint16_t *test_result);

/**
 * @brief Perform conditioning (recommended after 3+ hours idle)
 * @param handle Pointer to device handle
 * @return STCC4_OK on success
 */
STCC4_Status_t STCC4_PerformConditioning(STCC4_Handle_t *handle);

/**
 * @brief Enter sleep mode
 * @param handle Pointer to device handle
 * @return STCC4_OK on success
 */
STCC4_Status_t STCC4_EnterSleepMode(STCC4_Handle_t *handle);

/**
 * @brief Exit sleep mode
 * @param handle Pointer to device handle
 * @return STCC4_OK on success
 */
STCC4_Status_t STCC4_ExitSleepMode(STCC4_Handle_t *handle);

/**
 * @brief Perform factory reset
 * @param handle Pointer to device handle
 * @param reset_result Pointer to store reset result (0 = success)
 * @return STCC4_OK on success
 */
STCC4_Status_t STCC4_PerformFactoryReset(STCC4_Handle_t *handle, uint16_t *reset_result);

#endif /* STCC4_H */
