/**
 * @file stcc4.c
 * @brief STCC4 CO2 Sensor Driver Implementation for STM32 HAL
 */

#include "stcc4.h"
#include <string.h>

/* CRC-8 parameters for Sensirion protocol */
#define CRC8_POLYNOMIAL 0x31
#define CRC8_INIT       0xFF

/* Helper function prototypes */
static uint8_t STCC4_CalculateCRC(const uint8_t *data, uint8_t len);
static bool STCC4_CheckCRC(const uint8_t *data, uint8_t len, uint8_t crc);
static STCC4_Status_t STCC4_WriteCommand(STCC4_Handle_t *handle, uint16_t cmd);
static STCC4_Status_t STCC4_WriteCommandWithData(STCC4_Handle_t *handle, uint16_t cmd, const uint8_t *data, uint8_t data_len);
static STCC4_Status_t STCC4_ReadData(STCC4_Handle_t *handle, uint8_t *data, uint8_t len);

/**
 * @brief Calculate CRC-8 checksum
 */
static uint8_t STCC4_CalculateCRC(const uint8_t *data, uint8_t len) {
    uint8_t crc = CRC8_INIT;
    
    for (uint8_t i = 0; i < len; i++) {
        crc ^= data[i];
        for (uint8_t bit = 0; bit < 8; bit++) {
            if (crc & 0x80) {
                crc = (crc << 1) ^ CRC8_POLYNOMIAL;
            } else {
                crc = (crc << 1);
            }
        }
    }
    return crc;
}

/**
 * @brief Verify CRC-8 checksum
 */
static bool STCC4_CheckCRC(const uint8_t *data, uint8_t len, uint8_t crc) {
    return STCC4_CalculateCRC(data, len) == crc;
}

/**
 * @brief Write command to sensor
 */
static STCC4_Status_t STCC4_WriteCommand(STCC4_Handle_t *handle, uint16_t cmd) {
    uint8_t buf[2];
    buf[0] = (cmd >> 8) & 0xFF;
    buf[1] = cmd & 0xFF;
    
    HAL_StatusTypeDef status = HAL_I2C_Master_Transmit(
        handle->hi2c,
        handle->i2c_addr << 1,
        buf,
        2,
        STCC4_I2C_TIMEOUT
    );
    
    return (status == HAL_OK) ? STCC4_OK : STCC4_ERR_I2C;
}

/**
 * @brief Write command with data payload
 */
static STCC4_Status_t STCC4_WriteCommandWithData(STCC4_Handle_t *handle, uint16_t cmd, const uint8_t *data, uint8_t data_len) {
    uint8_t buf[20];
    uint8_t idx = 0;
    
    // Command bytes
    buf[idx++] = (cmd >> 8) & 0xFF;
    buf[idx++] = cmd & 0xFF;
    
    // Data bytes with CRC
    for (uint8_t i = 0; i < data_len; i += 2) {
        buf[idx++] = data[i];
        buf[idx++] = data[i + 1];
        buf[idx++] = STCC4_CalculateCRC(&data[i], 2);
    }
    
    HAL_StatusTypeDef status = HAL_I2C_Master_Transmit(
        handle->hi2c,
        handle->i2c_addr << 1,
        buf,
        idx,
        STCC4_I2C_TIMEOUT
    );
    
    return (status == HAL_OK) ? STCC4_OK : STCC4_ERR_I2C;
}

/**
 * @brief Read data from sensor with CRC validation
 */
static STCC4_Status_t STCC4_ReadData(STCC4_Handle_t *handle, uint8_t *data, uint8_t len) {
    uint8_t buf[20];
    uint8_t words = len / 2;
    uint8_t buf_len = words * 3; // Each word has 2 bytes + 1 CRC
    
    HAL_StatusTypeDef status = HAL_I2C_Master_Receive(
        handle->hi2c,
        handle->i2c_addr << 1,
        buf,
        buf_len,
        STCC4_I2C_TIMEOUT
    );
    
    if (status != HAL_OK) {
        return STCC4_ERR_I2C;
    }
    
    // Validate CRC and extract data
    uint8_t data_idx = 0;
    for (uint8_t i = 0; i < buf_len; i += 3) {
        if (!STCC4_CheckCRC(&buf[i], 2, buf[i + 2])) {
            return STCC4_ERR_CRC;
        }
        data[data_idx++] = buf[i];
        data[data_idx++] = buf[i + 1];
    }
    
    return STCC4_OK;
}

/**
 * @brief Initialize STCC4 sensor
 */
STCC4_Status_t STCC4_Init(STCC4_Handle_t *handle, I2C_HandleTypeDef *hi2c, uint8_t i2c_addr) {
    if (!handle || !hi2c) {
        return STCC4_ERR_PARAM;
    }
    
    handle->hi2c = hi2c;
    handle->i2c_addr = i2c_addr;
    
    return STCC4_OK;
}

/**
 * @brief Start continuous measurement
 */
STCC4_Status_t STCC4_StartContinuousMeasurement(STCC4_Handle_t *handle) {
    return STCC4_WriteCommand(handle, STCC4_CMD_START_CONTINUOUS);
}

/**
 * @brief Stop continuous measurement
 */
STCC4_Status_t STCC4_StopContinuousMeasurement(STCC4_Handle_t *handle) {
    STCC4_Status_t status = STCC4_WriteCommand(handle, STCC4_CMD_STOP_CONTINUOUS);
    if (status == STCC4_OK) {
        HAL_Delay(STCC4_DELAY_STOP_MEASURE);
    }
    return status;
}

/**
 * @brief Read measurement data
 */
STCC4_Status_t STCC4_ReadMeasurement(STCC4_Handle_t *handle, STCC4_Measurement_t *measurement) {
    if (!handle || !measurement) {
        return STCC4_ERR_PARAM;
    }
    
    // Send read command
    STCC4_Status_t status = STCC4_WriteCommand(handle, STCC4_CMD_READ_MEASUREMENT);
    if (status != STCC4_OK) {
        return status;
    }
    
    HAL_Delay(STCC4_DELAY_READ_MEASURE);
    
    // Read 8 bytes (4 words with CRC)
    uint8_t data[8];
    status = STCC4_ReadData(handle, data, 8);
    if (status != STCC4_OK) {
        return status;
    }
    
    // Parse data
    measurement->co2_ppm = (int16_t)((data[0] << 8) | data[1]);
    uint16_t raw_temp = (data[2] << 8) | data[3];
    uint16_t raw_hum = (data[4] << 8) | data[5];
    measurement->sensor_status = (data[6] << 8) | data[7];
    
    // Convert temperature: t = -45 + 175 * s / 65535
    measurement->temperature_c = -45.0f + (175.0f * raw_temp / 65535.0f);
    
    // Convert humidity: rh = -6 + 125 * s / 65535
    measurement->humidity_percent = -6.0f + (125.0f * raw_hum / 65535.0f);
    
    return STCC4_OK;
}

/**
 * @brief Perform single shot measurement
 */
STCC4_Status_t STCC4_MeasureSingleShot(STCC4_Handle_t *handle) {
    STCC4_Status_t status = STCC4_WriteCommand(handle, STCC4_CMD_MEASURE_SINGLE_SHOT);
    if (status == STCC4_OK) {
        HAL_Delay(STCC4_DELAY_SINGLE_SHOT);
    }
    return status;
}

/**
 * @brief Get product ID and serial number
 */
STCC4_Status_t STCC4_GetProductId(STCC4_Handle_t *handle, uint32_t *product_id, uint64_t *serial_number) {
    if (!handle || !product_id || !serial_number) {
        return STCC4_ERR_PARAM;
    }
    
    STCC4_Status_t status = STCC4_WriteCommand(handle, STCC4_CMD_GET_PRODUCT_ID);
    if (status != STCC4_OK) {
        return status;
    }
    
    HAL_Delay(STCC4_DELAY_GET_PRODUCT_ID);
    
    // Read 12 bytes (6 words with CRC)
    uint8_t data[12];
    status = STCC4_ReadData(handle, data, 12);
    if (status != STCC4_OK) {
        return status;
    }
    
    // Parse product ID (4 bytes)
    *product_id = ((uint32_t)data[0] << 24) | ((uint32_t)data[1] << 16) |
                  ((uint32_t)data[2] << 8) | data[3];
    
    // Parse serial number (8 bytes)
    *serial_number = ((uint64_t)data[4] << 56) | ((uint64_t)data[5] << 48) |
                     ((uint64_t)data[6] << 40) | ((uint64_t)data[7] << 32) |
                     ((uint64_t)data[8] << 24) | ((uint64_t)data[9] << 16) |
                     ((uint64_t)data[10] << 8) | data[11];
    
    return STCC4_OK;
}

/**
 * @brief Set pressure compensation
 */
STCC4_Status_t STCC4_SetPressureCompensation(STCC4_Handle_t *handle, uint16_t pressure_pa) {
    uint16_t pressure_raw = pressure_pa / 2;
    uint8_t data[2];
    data[0] = (pressure_raw >> 8) & 0xFF;
    data[1] = pressure_raw & 0xFF;
    
    STCC4_Status_t status = STCC4_WriteCommandWithData(handle, STCC4_CMD_SET_PRESSURE_RAW, data, 2);
    if (status == STCC4_OK) {
        HAL_Delay(STCC4_DELAY_SET_PRESSURE);
    }
    return status;
}

/**
 * @brief Set RH/T compensation
 */
STCC4_Status_t STCC4_SetRhtCompensation(STCC4_Handle_t *handle, uint16_t raw_temp, uint16_t raw_humidity) {
    uint8_t data[4];
    data[0] = (raw_temp >> 8) & 0xFF;
    data[1] = raw_temp & 0xFF;
    data[2] = (raw_humidity >> 8) & 0xFF;
    data[3] = raw_humidity & 0xFF;
    
    STCC4_Status_t status = STCC4_WriteCommandWithData(handle, STCC4_CMD_SET_RHT_COMPENSATION, data, 4);
    if (status == STCC4_OK) {
        HAL_Delay(STCC4_DELAY_SET_RHT);
    }
    return status;
}

/**
 * @brief Perform forced recalibration
 */
STCC4_Status_t STCC4_PerformForcedRecalibration(STCC4_Handle_t *handle, int16_t target_co2_ppm, int16_t *frc_correction) {
    if (!handle || !frc_correction) {
        return STCC4_ERR_PARAM;
    }
    
    uint8_t data[2];
    data[0] = (target_co2_ppm >> 8) & 0xFF;
    data[1] = target_co2_ppm & 0xFF;
    
    STCC4_Status_t status = STCC4_WriteCommandWithData(handle, STCC4_CMD_FORCED_RECALIBRATION, data, 2);
    if (status != STCC4_OK) {
        return status;
    }
    
    HAL_Delay(STCC4_DELAY_FORCED_RECAL);
    
    uint8_t result[2];
    status = STCC4_ReadData(handle, result, 2);
    if (status == STCC4_OK) {
        *frc_correction = (int16_t)((result[0] << 8) | result[1]);
    }
    
    return status;
}

/**
 * @brief Perform self-test
 */
STCC4_Status_t STCC4_PerformSelfTest(STCC4_Handle_t *handle, uint16_t *test_result) {
    if (!handle || !test_result) {
        return STCC4_ERR_PARAM;
    }
    
    STCC4_Status_t status = STCC4_WriteCommand(handle, STCC4_CMD_SELF_TEST);
    if (status != STCC4_OK) {
        return status;
    }
    
    HAL_Delay(STCC4_DELAY_SELF_TEST);
    
    uint8_t data[2];
    status = STCC4_ReadData(handle, data, 2);
    if (status == STCC4_OK) {
        *test_result = (data[0] << 8) | data[1];
    }
    
    return status;
}

/**
 * @brief Perform conditioning
 */
STCC4_Status_t STCC4_PerformConditioning(STCC4_Handle_t *handle) {
    STCC4_Status_t status = STCC4_WriteCommand(handle, STCC4_CMD_CONDITIONING);
    if (status == STCC4_OK) {
        HAL_Delay(STCC4_DELAY_CONDITIONING);
    }
    return status;
}

/**
 * @brief Enter sleep mode
 */
STCC4_Status_t STCC4_EnterSleepMode(STCC4_Handle_t *handle) {
    STCC4_Status_t status = STCC4_WriteCommand(handle, STCC4_CMD_ENTER_SLEEP);
    if (status == STCC4_OK) {
        HAL_Delay(STCC4_DELAY_ENTER_SLEEP);
    }
    return status;
}

/**
 * @brief Exit sleep mode
 */
STCC4_Status_t STCC4_ExitSleepMode(STCC4_Handle_t *handle) {
    uint8_t buf = 0x00;
    HAL_StatusTypeDef status = HAL_I2C_Master_Transmit(
        handle->hi2c,
        handle->i2c_addr << 1,
        &buf,
        1,
        STCC4_I2C_TIMEOUT
    );
    
    if (status == HAL_OK) {
        HAL_Delay(STCC4_DELAY_EXIT_SLEEP);
        return STCC4_OK;
    }
    return STCC4_ERR_I2C;
}

/**
 * @brief Perform factory reset
 */
STCC4_Status_t STCC4_PerformFactoryReset(STCC4_Handle_t *handle, uint16_t *reset_result) {
    if (!handle || !reset_result) {
        return STCC4_ERR_PARAM;
    }
    
    STCC4_Status_t status = STCC4_WriteCommand(handle, STCC4_CMD_FACTORY_RESET);
    if (status != STCC4_OK) {
        return status;
    }
    
    HAL_Delay(STCC4_DELAY_FORCED_RECAL);
    
    uint8_t data[2];
    status = STCC4_ReadData(handle, data, 2);
    if (status == STCC4_OK) {
        *reset_result = (data[0] << 8) | data[1];
    }
    
    return status;
}