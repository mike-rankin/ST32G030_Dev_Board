/*
 * SEN66 HAL Driver for STM32
 * Converted from Arduino library to STM32 HAL
 */

#ifndef SEN66_HAL_H
#define SEN66_HAL_H

#include "main.h"
#include <stdint.h>
#include <stdbool.h>

// I2C Address
#define SEN66_I2C_ADDR 0x6B

// Command IDs
#define SEN66_CMD_START_MEASUREMENT         0x0021
#define SEN66_CMD_STOP_MEASUREMENT          0x0104
#define SEN66_CMD_GET_DATA_READY            0x0202
#define SEN66_CMD_READ_MEASURED_VALUES      0x0300
#define SEN66_CMD_GET_SERIAL_NUMBER         0xD033
#define SEN66_CMD_GET_PRODUCT_NAME          0xD014
#define SEN66_CMD_GET_VERSION               0xD100
#define SEN66_CMD_DEVICE_RESET              0xD304

// Error codes
#define SEN66_OK                    0
#define SEN66_ERR_I2C              -1
#define SEN66_ERR_CRC              -2
#define SEN66_ERR_TIMEOUT          -3

// Device Status structure
typedef union {
    struct {
        uint32_t reserved1 : 4;
        uint32_t fanError : 1;
        uint32_t reserved2 : 1;
        uint32_t rhtError : 1;
        uint32_t gasError : 1;
        uint32_t reserved3 : 1;
        uint32_t co2Error : 1;
        uint32_t reserved4 : 1;
        uint32_t pmError : 1;
        uint32_t reserved5 : 1;
        uint32_t reserved6 : 8;
        uint32_t fanSpeedWarning : 1;
    };
    uint32_t value;
} SEN66_DeviceStatus_t;

// Measurement data structure
typedef struct {
    float massConcentrationPm1p0;   // µg/m³
    float massConcentrationPm2p5;   // µg/m³
    float massConcentrationPm4p0;   // µg/m³
    float massConcentrationPm10p0;  // µg/m³
    float humidity;                  // %RH
    float temperature;               // °C
    float vocIndex;                  // 0-500
    float noxIndex;                  // 0-500
    uint16_t co2;                    // ppm
} SEN66_MeasuredValues_t;

// Function prototypes
int16_t SEN66_Init(I2C_HandleTypeDef *hi2c);
int16_t SEN66_DeviceReset(void);
int16_t SEN66_StartMeasurement(void);
int16_t SEN66_StopMeasurement(void);
int16_t SEN66_GetDataReady(bool *dataReady);
int16_t SEN66_ReadMeasuredValues(SEN66_MeasuredValues_t *values);
int16_t SEN66_GetSerialNumber(char *serialNumber, uint16_t size);
int16_t SEN66_GetProductName(char *productName, uint16_t size);
int16_t SEN66_GetVersion(uint8_t *firmwareMajor, uint8_t *firmwareMinor);

#endif // SEN66_HAL_H