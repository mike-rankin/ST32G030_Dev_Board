/*
 * SEN66 HAL Driver for STM32
 * Converted from Arduino library to STM32 HAL
 */

#include "sen66_hal.h"
#include <string.h>

// Private variables
static I2C_HandleTypeDef *_hi2c = NULL;
static uint8_t _i2c_addr = SEN66_I2C_ADDR << 1;

// CRC calculation (Sensirion CRC-8)
static uint8_t SEN66_CalcCRC(const uint8_t *data, uint16_t len) {
    uint8_t crc = 0xFF;
    for (uint16_t i = 0; i < len; i++) {
        crc ^= data[i];
        for (uint8_t bit = 0; bit < 8; bit++) {
            if (crc & 0x80) {
                crc = (crc << 1) ^ 0x31;
            } else {
                crc = (crc << 1);
            }
        }
    }
    return crc;
}

// Send I2C command
static int16_t SEN66_SendCommand(uint16_t cmd) {
    uint8_t buffer[2];
    buffer[0] = (cmd >> 8) & 0xFF;
    buffer[1] = cmd & 0xFF;
    
    if (HAL_I2C_Master_Transmit(_hi2c, _i2c_addr, buffer, 2, 100) != HAL_OK) {
        return SEN66_ERR_I2C;
    }
    return SEN66_OK;
}

// Send I2C command with data
static int16_t SEN66_SendCommandWithData(uint16_t cmd, const uint8_t *data, uint16_t dataLen) {
    uint8_t buffer[64];
    uint16_t pos = 0;
    
    // Add command
    buffer[pos++] = (cmd >> 8) & 0xFF;
    buffer[pos++] = cmd & 0xFF;
    
    // Add data with CRC
    for (uint16_t i = 0; i < dataLen; i += 2) {
        buffer[pos++] = data[i];
        buffer[pos++] = data[i + 1];
        buffer[pos++] = SEN66_CalcCRC(&data[i], 2);
    }
    
    if (HAL_I2C_Master_Transmit(_hi2c, _i2c_addr, buffer, pos, 100) != HAL_OK) {
        return SEN66_ERR_I2C;
    }
    return SEN66_OK;
}

// Read I2C data with CRC check
static int16_t SEN66_ReadData(uint8_t *data, uint16_t dataLen) {
    uint8_t buffer[64];
    uint16_t readLen = (dataLen / 2) * 3; // 2 bytes data + 1 byte CRC per word
    
    if (HAL_I2C_Master_Receive(_hi2c, _i2c_addr, buffer, readLen, 100) != HAL_OK) {
        return SEN66_ERR_I2C;
    }
    
    // Extract data and verify CRC
    uint16_t dataPos = 0;
    for (uint16_t i = 0; i < readLen; i += 3) {
        uint8_t crc = SEN66_CalcCRC(&buffer[i], 2);
        if (crc != buffer[i + 2]) {
            return SEN66_ERR_CRC;
        }
        data[dataPos++] = buffer[i];
        data[dataPos++] = buffer[i + 1];
    }
    
    return SEN66_OK;
}

// Initialize SEN66
int16_t SEN66_Init(I2C_HandleTypeDef *hi2c) {
    _hi2c = hi2c;
    return SEN66_OK;
}

// Reset device
int16_t SEN66_DeviceReset(void) {
    int16_t error = SEN66_SendCommand(SEN66_CMD_DEVICE_RESET);
    if (error != SEN66_OK) {
        return error;
    }
    HAL_Delay(1200); // Wait for reset to complete
    return SEN66_OK;
}

// Start continuous measurement
int16_t SEN66_StartMeasurement(void) {
    int16_t error = SEN66_SendCommand(SEN66_CMD_START_MEASUREMENT);
    if (error != SEN66_OK) {
        return error;
    }
    HAL_Delay(50);
    return SEN66_OK;
}

// Stop measurement
int16_t SEN66_StopMeasurement(void) {
    int16_t error = SEN66_SendCommand(SEN66_CMD_STOP_MEASUREMENT);
    if (error != SEN66_OK) {
        return error;
    }
    HAL_Delay(1000);
    return SEN66_OK;
}

// Check if data is ready
int16_t SEN66_GetDataReady(bool *dataReady) {
    int16_t error;
    uint8_t data[2];
    
    error = SEN66_SendCommand(SEN66_CMD_GET_DATA_READY);
    if (error != SEN66_OK) {
        return error;
    }
    
    HAL_Delay(20);
    
    error = SEN66_ReadData(data, 2);
    if (error != SEN66_OK) {
        return error;
    }
    
    *dataReady = (data[1] != 0);
    return SEN66_OK;
}

// Read measured values
int16_t SEN66_ReadMeasuredValues(SEN66_MeasuredValues_t *values) {
    int16_t error;
    uint8_t data[18]; // 9 words = 18 bytes
    
    error = SEN66_SendCommand(SEN66_CMD_READ_MEASURED_VALUES);
    if (error != SEN66_OK) {
        return error;
    }
    
    HAL_Delay(20);
    
    error = SEN66_ReadData(data, 18);
    if (error != SEN66_OK) {
        return error;
    }
    
    // Parse data
    uint16_t pm1p0_raw = (data[0] << 8) | data[1];
    uint16_t pm2p5_raw = (data[2] << 8) | data[3];
    uint16_t pm4p0_raw = (data[4] << 8) | data[5];
    uint16_t pm10p0_raw = (data[6] << 8) | data[7];
    int16_t humidity_raw = (data[8] << 8) | data[9];
    int16_t temperature_raw = (data[10] << 8) | data[11];
    int16_t voc_raw = (data[12] << 8) | data[13];
    int16_t nox_raw = (data[14] << 8) | data[15];
    uint16_t co2_raw = (data[16] << 8) | data[17];
    
    // Apply scaling factors
    values->massConcentrationPm1p0 = pm1p0_raw / 10.0f;
    values->massConcentrationPm2p5 = pm2p5_raw / 10.0f;
    values->massConcentrationPm4p0 = pm4p0_raw / 10.0f;
    values->massConcentrationPm10p0 = pm10p0_raw / 10.0f;
    values->humidity = humidity_raw / 100.0f;
    values->temperature = temperature_raw / 200.0f;
    values->vocIndex = voc_raw / 10.0f;
    values->noxIndex = nox_raw / 10.0f;
    values->co2 = co2_raw;
    
    return SEN66_OK;
}

// Get serial number
int16_t SEN66_GetSerialNumber(char *serialNumber, uint16_t size) {
    int16_t error;
    uint8_t data[32];
    
    error = SEN66_SendCommand(SEN66_CMD_GET_SERIAL_NUMBER);
    if (error != SEN66_OK) {
        return error;
    }
    
    HAL_Delay(20);
    
    error = SEN66_ReadData(data, 32);
    if (error != SEN66_OK) {
        return error;
    }
    
    // Copy serial number
    uint16_t copyLen = (size < 32) ? size - 1 : 31;
    memcpy(serialNumber, data, copyLen);
    serialNumber[copyLen] = '\0';
    
    return SEN66_OK;
}

// Get product name
int16_t SEN66_GetProductName(char *productName, uint16_t size) {
    int16_t error;
    uint8_t data[32];
    
    error = SEN66_SendCommand(SEN66_CMD_GET_PRODUCT_NAME);
    if (error != SEN66_OK) {
        return error;
    }
    
    HAL_Delay(20);
    
    error = SEN66_ReadData(data, 32);
    if (error != SEN66_OK) {
        return error;
    }
    
    // Copy product name
    uint16_t copyLen = (size < 32) ? size - 1 : 31;
    memcpy(productName, data, copyLen);
    productName[copyLen] = '\0';
    
    return SEN66_OK;
}

// Get firmware version
int16_t SEN66_GetVersion(uint8_t *firmwareMajor, uint8_t *firmwareMinor) {
    int16_t error;
    uint8_t data[2];
    
    error = SEN66_SendCommand(SEN66_CMD_GET_VERSION);
    if (error != SEN66_OK) {
        return error;
    }
    
    HAL_Delay(20);
    
    error = SEN66_ReadData(data, 2);
    if (error != SEN66_OK) {
        return error;
    }
    
    *firmwareMajor = data[0];
    *firmwareMinor = data[1];
    
    return SEN66_OK;
}